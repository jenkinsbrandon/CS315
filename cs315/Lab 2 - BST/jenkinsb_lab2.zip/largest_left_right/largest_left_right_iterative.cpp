#include <stdio.h>
#include "largest_left_right_iterative.hpp"
#include <vector>
#include <iostream>
#include <tuple>


std::tuple<int, int> largest_left(std::vector<int> v, int base_number_index)
{
	int k = base_number_index;
	std::tuple<int,int> left_tuple;
	left_tuple = std::make_tuple( 0 , 0 );

	while(  k >= 0 )
	{
		
	//	std::cout<< "Num: " << v.at(k) << "\t" << "Comp: " << v.at(base_number_index) << std::endl;
		if( v.at(base_number_index) < v.at(k) )
		{
			left_tuple = std::make_tuple( k, v.at(k) );
			return left_tuple;
		}
		
		k--;
	}
	return left_tuple;
}


std::tuple<int, int> largest_right(std::vector<int> v, int base_number_index)
{

	int k = base_number_index;
	std::tuple<int,int> right_tuple;
	right_tuple = std::make_tuple( 0 , 0 );

	while(  k < v.size() )
	{
		
	//	std::cout<< "Num: " << v.at(k) << "\t" << "Comp: " << v.at(base_number_index) << std::endl;
		if( v.at(base_number_index) < v.at(k) )
		{
			right_tuple = std::make_tuple( k, v.at(k) );
			return right_tuple;
		}
		
		k++;
	}
	return right_tuple;
}

int largest_left_right(std::vector<int> v, int base_number_index)
{
	int result_number = 0;

	if(base_number_index == v.size() - 1)
	{
		return std::get<1>(largest_left(v, base_number_index));
	}
	else if( base_number_index == 0 )
	{
		return std::get<1>(largest_right(v, base_number_index));
	}	
	else
	{

		std::tuple<int,int> left_tuple = largest_left(v, base_number_index );
		std::tuple<int,int> right_tuple = largest_right(v, base_number_index );
		
		if(base_number_index - std::get<0>(left_tuple) < std::get<0>(right_tuple) - base_number_index)
		{
			return std::get<1>(left_tuple);
		}
		else if(base_number_index - std::get<0>(left_tuple) > std::get<0>(right_tuple) - base_number_index)
		{
			return std::get<1>(right_tuple);
		}
		else
		{
			if( std::get<1>(left_tuple) > std::get<1>(right_tuple) )
			{
				return std::get<1>(left_tuple);
			}
			else
			{
				return std::get<1>(right_tuple);
			}
		}
	}


	return 0;
}

void largest_left_right_iterative(std::vector<int>&numbers, std::vector<int> &result)
{
	int i = 0;
	int result_number = 0;


	//std::cout<< "Numbers size: " << numbers.size() << std::endl << "Vector of Numbers: " << std::endl;
	while( i < numbers.size() )
	{
		result_number = largest_left_right( numbers, i );
		result.push_back(result_number);

		i++;
	}
}

