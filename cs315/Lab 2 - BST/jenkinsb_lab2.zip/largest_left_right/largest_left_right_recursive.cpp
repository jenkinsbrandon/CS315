#include <stdio.h>
#include "largest_left_right_recursive.hpp"
#include <vector>
#include <iostream>
#include <tuple>

std::tuple<int,int> largest_left(std::vector<int> v, int base_number, int j)
{
	if( j ==  0 )
	{
		return std::make_tuple( 0, 0 );
	}

	//std::cout<<"Base: " << base_number << "j: " << v.at(j-1) << std::endl;	
	if( (base_number) < v.at(j - 1) )
	{
		//std::cout << "jA: " << j << std::endl;
		return std::make_tuple( j, v.at(j - 1));
	}

	//std::cout << "j: " << j << std::endl;
	largest_left( v, base_number, j - 1 );
	
}

std::tuple<int,int> largest_right(std::vector<int> v, int base_number, int i)
{
	if( i == v.size()-1 )
	{
		return std::make_tuple( 0, 0 );
	}
	
	if( (base_number) < v.at(i + 1) )
	{
		//std::cout << "IA: " << v.at(i) << std::endl;
		return std::make_tuple( i ,v.at(i + 1));
	}

	
//	std::cout << "I: " << i << std::endl;
	largest_right( v, base_number, i + 1 );
	
}

void largest_left_right_recursive(std::vector<int>&numbers, std::vector<int> &result, int n)
{
	int i = n - 1;
	if( i == -1 )
	{
		return;
	}

	std::tuple<int,int> left_tuple;
	std::tuple<int,int> right_tuple;

	left_tuple = largest_left( numbers, i, i );
	right_tuple = largest_right( numbers, i, i );

		//std::cout<<"NumberL: "<<  std::get<0>(left_tuple) << std::endl;
                //std::cout<<"NumberR: "<<  std::get<0>(right_tuple) << std::endl;

	int result_number = 0;

	if(i - std::get<0>(left_tuple) > std::get<0>(right_tuple) - i)
        {
                result_number =  std::get<1>(left_tuple);
		//std::cout<<"LEFT "<< result_number << std::endl;
        }
        else if(i - std::get<0>(left_tuple) < std::get<0>(right_tuple) - i)
        {
                result_number = std::get<1>(right_tuple);
		//std::cout<<"RIGHT "<< result_number << std::endl;
        }
        else
        {
                if( std::get<1>(left_tuple) > std::get<1>(right_tuple) )
                {
                        result_number =  std::get<1>(left_tuple);
                }
                else
                {
                        result_number = std::get<1>(right_tuple);
                }

		//std::cout<<"EQ "<< result_number << std::endl;
        }

	result.push_back( result_number );

	largest_left_right_recursive( numbers, result, n - 1 );
}

