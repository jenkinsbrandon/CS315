
#include <vector>

void largest_left_right_recursive(const std::vector<int>&numbers, std::vector<int> &result, int n);

