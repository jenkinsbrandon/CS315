#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>

#include "read_input.cpp"
#include "largest_left_right_iterative.cpp"


int main(int argc, char *argv[])
{
	if( argc != 2 )
	{
		std::cout << "usage:" << argv[0] << " nameOfInputFile\n";
		exit(2);
	}
	
	std::vector<int> numbers;        
	std::vector<int> result;
	
	read_numbers(std::string(argv[1]), numbers);

//	std::cout << numbers.size() << std::endl;
	largest_left_right_iterative(numbers,result);
	
	for( int i: result )
	{
		std::cout << i << std::endl;
	}

	return 0;
}

