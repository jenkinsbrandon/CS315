
#include <vector>

void largest_left_right_iterative(const std::vector<int>&numbers, std::vector<int> &result);




