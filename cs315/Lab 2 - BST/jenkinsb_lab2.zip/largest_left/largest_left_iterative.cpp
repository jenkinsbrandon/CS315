#include <stdio.h>
#include "largest_left_iterative.hpp"
#include <vector>
#include <iostream>

int largest_left(std::vector<int> v, int j)
{
	int k = j;
	while( k >= 0 )
	{
		
		//std::cout<< "Num: " << v.at(j) << "\t" << "Comp: " << v.at(k) << std::endl;
		if( v.at(j) < v.at(k) )
		{
			return v.at(k);
		}
		
		k--;
	}
	return 0;
}

void largest_left_iterative(std::vector<int>&numbers, std::vector<int> &result)
{
	int i = 1;
	int result_number = 0;

	result.push_back(result_number);
	//std::cout<< "Numbers size: " << numbers.size() << std::endl << "Vector of Numbers: " << std::endl;
	while( i < numbers.size() )
	{
		result_number = largest_left( numbers, i );
		result.push_back(result_number);

		i++;
	}
}

