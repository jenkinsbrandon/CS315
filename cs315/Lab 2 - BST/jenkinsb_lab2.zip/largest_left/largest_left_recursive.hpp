
#include <vector>

void largest_left_recursive(const std::vector<int>&numbers, std::vector<int> &result, int n);

