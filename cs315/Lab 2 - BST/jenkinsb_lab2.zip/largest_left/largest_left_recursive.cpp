#include <stdio.h>
#include "largest_left_recursive.hpp"
#include <vector>
#include <iostream>

int largest_left(std::vector<int> v, int base_number, int i)
{
	if( i == 0 )
	{
		return 0;
	}
	if( base_number < v.at(i - 1) )
	{
		return v.at(i - 1);
	}

	return largest_left( v, base_number, i - 1 );
	
}

void largest_left_recursive(std::vector<int>&numbers, std::vector<int> &result, int n)
{
	int i = n - 1;
	if( i == 0 )
	{
		result.push_back(0);
		return;
	}

	result.push_back( largest_left( numbers, numbers.at(i), i ) );

	largest_left_recursive( numbers, result, n - 1 );
}

