//
// Created by Ali A. Kooshesh on 2019-09-17.
//
#include<iostream>
#include<string>
#include<vector>

#include "read_input.cpp"
#include "largest_left_recursive.cpp"

int main(int argc, char *argv[]) {
    if( argc != 2 ) {
        std::cout << "usage:" << argv[0] << " nameOfInputFile\n";
        exit(2);
    }

    std::vector<int> numbers, result;
    read_numbers(std::string(argv[1]), numbers);
    largest_left_recursive(numbers, result, numbers.size());
    int i = result.size() - 1;
    while( i >= 0 )
    {
        std::cout << result.at(i) << std::endl;
	i--;
    }

    return 0;
}


