
#include <vector>

int count_inversions_recursive(const std::vector<int>&numbers, int n);



