#include <stdio.h>
#include "count_inversion_recursive.hpp"
#include <vector>
#include <iostream>

int count_inversions_recursive(std::vector<int>&v, int n )
{
	//std:: cout << v.size()<<std::endl;
	int i = n - 1;

	if( i == 0 )
	{
		return 0;
	}
	
	if( v.at(i) < v.at(i-1) )
	{	
		return 1 + count_inversions_recursive( v, i );
	}
	else
	{
		return count_inversions_recursive( v, i );  
	}

}
