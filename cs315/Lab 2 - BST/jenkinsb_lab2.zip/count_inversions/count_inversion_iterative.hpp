
#include <vector>

int count_inversions_iterative(const std::vector<int>&numbers);



