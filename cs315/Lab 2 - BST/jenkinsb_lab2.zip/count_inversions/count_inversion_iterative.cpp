#include <stdio.h>
#include "count_inversion_iterative.hpp"
#include <vector>
#include <iostream>

int count_inversions_iterative(std::vector<int>&v )
{
	int i = 0;
	int count = 0;
	while( i < v.size()-1)
	{
		if( v.at(i) > v.at(i+1) )
		       count++;
		i++;	
	}
	return count;
}
