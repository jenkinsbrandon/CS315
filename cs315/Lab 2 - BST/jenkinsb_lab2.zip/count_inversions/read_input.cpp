

#include <stdio.h>
#include <vector>
#include <iostream>
#include <fstream>

#include "read_input.hpp"

void read_numbers(std::string fileName, std::vector<int>&v)
{
	std::ifstream file;
	file.open( fileName );
	int numbers;
	while( file >> numbers )
	{
		v.push_back(numbers);
	}
}

