
#include <vector>
int increasing_sequence_iterative(std::vector<int> &numbers);
