#include <stdio.h>
#include "increasing_sequence_recursive.hpp"
#include <vector>
#include <iostream>
int global_count = 1;
int global_sequence = 0;
int count_of_sequence(std::vector<int> v, int i )
{
	if(i == v.size() - 1)
	{
		return global_sequence;
	}
	if( v.at(i) < v.at(i + 1))
	{
		//std::cout<<global_count<<std::endl;
		global_count++;
	}
	else
	{
		global_count = 1;
	}
	if( global_count > global_sequence )
	{
		global_sequence = global_count;
	}

	count_of_sequence( v, i + 1 );			

}

int increasing_sequence_recursive(std::vector<int> &numbers, int startIdx)
{
	int count = 1;
	if( startIdx >= numbers.size() -1 )
	{
		return global_sequence;
	}
	count_of_sequence(numbers, startIdx);
	increasing_sequence_recursive(numbers, startIdx + 1);
}

