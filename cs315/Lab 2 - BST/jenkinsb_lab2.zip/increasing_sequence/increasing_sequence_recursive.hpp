#include <stdio.h>
#include <vector>

int increasing_sequence_recursive(std::vector<int> &numbers, int startIdx);
