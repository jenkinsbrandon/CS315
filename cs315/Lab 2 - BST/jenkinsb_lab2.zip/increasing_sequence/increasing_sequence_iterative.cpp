#include <stdio.h>
#include "increasing_sequence_iterative.hpp"
#include <vector>
#include <iostream>

int increasing_sequence_iterative(std::vector<int> &numbers)
{
	int i = 0;
	int count = 1;
	int sequence = 0;

	while(i < numbers.size() - 1)
	{
		if( numbers.at(i) <= numbers.at(i + 1))
		{	
			count++;
		}
		else
		{
			count = 1;
		}
		if( count > sequence )
		{
			sequence = count;
		}

		i++;

	}

	return sequence;
}

